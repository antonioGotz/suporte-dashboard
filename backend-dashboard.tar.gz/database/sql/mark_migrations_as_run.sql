-- Safe script to mark specific migrations as ran without altering existing tables
-- Usage (MySQL/MariaDB):
--   mysql -u <user> -p <database> < backend-laravel/database/sql/mark_migrations_as_run.sql

-- Choose a high batch number to keep history clear
SET @batch := 999;

INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2020_01_01_000000_create_actions_log_table', @batch
WHERE NOT EXISTS (
  SELECT 1 FROM `migrations` WHERE `migration` = '2020_01_01_000000_create_actions_log_table'
);

INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2020_01_02_000000_create_orders_table', @batch
WHERE NOT EXISTS (
  SELECT 1 FROM `migrations` WHERE `migration` = '2020_01_02_000000_create_orders_table'
);

INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2020_01_03_000000_create_children_table', @batch
WHERE NOT EXISTS (
  SELECT 1 FROM `migrations` WHERE `migration` = '2020_01_03_000000_create_children_table'
);

INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2025_10_01_191214_add_is_admin_to_users_table', @batch
WHERE NOT EXISTS (
  SELECT 1 FROM `migrations` WHERE `migration` = '2025_10_01_191214_add_is_admin_to_users_table'
);

INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2025_10_08_000001_add_address_fields_to_users_table', @batch
WHERE NOT EXISTS (
  SELECT 1 FROM `migrations` WHERE `migration` = '2025_10_08_000001_add_address_fields_to_users_table'
);

INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2025_10_08_000001_add_label_status_to_orders_table', @batch
WHERE NOT EXISTS (
  SELECT 1 FROM `migrations` WHERE `migration` = '2025_10_08_000001_add_label_status_to_orders_table'
);

INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2025_10_09_000001_fix_orders_id_autoincrement', @batch
WHERE NOT EXISTS (
  SELECT 1 FROM `migrations` WHERE `migration` = '2025_10_09_000001_fix_orders_id_autoincrement'
);

INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2025_10_11_000000_create_notifications_table', @batch
WHERE NOT EXISTS (
  SELECT 1 FROM `migrations` WHERE `migration` = '2025_10_11_000000_create_notifications_table'
);

